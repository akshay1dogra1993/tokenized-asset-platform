# Gold Batch Token — Setup & Run Guide

This is the actual contract, tests, and deployment script that were built and verified (17/17 tests passing, ~96% coverage). Follow these steps on your own machine to run it from scratch.

## 0. Prerequisites
- **Node.js** v18 or v20 (check with `node -v`). Get it from https://nodejs.org if you don't have it.
- **npm** (comes with Node).
- A code editor (VS Code is fine).

## 1. Set up the project

```bash
# from inside this folder (gold-batch-contracts/)
npm install
```

This reads `package.json` and installs Hardhat, the toolbox plugin, and OpenZeppelin Contracts. It'll create a `node_modules/` folder — that's normal and already excluded from git via `.gitignore`.

If `npm install` pulls in **Hardhat 3** instead of Hardhat 2 (check with `npx hardhat --version` — should print `2.29.x`), run:
```bash
npm install --save-dev hardhat@^2.22.0 @nomicfoundation/hardhat-toolbox@^5.0.0
```
This project is written for Hardhat 2's plugin/config style (CommonJS `require`, Mocha/Chai), so staying on 2.x matters.

## 2. Compile the contract

```bash
npx hardhat compile
```
You should see: `Compiled 1 Solidity file successfully`. The first run downloads the Solidity 0.8.24 compiler binary automatically — this needs internet access once, then it's cached locally.

## 3. Run the tests

```bash
npx hardhat test
```
Expected output: **17 passing** tests, covering whitelist rules, batch creation, minting, supply caps, and transfer gating.

## 4. (Optional) Check test coverage

```bash
npx hardhat coverage
```
Opens a report showing which lines/branches are exercised by the tests. You should see high coverage (~95%+) on `GoldBatchToken.sol`.

## 5. (Optional) Run Slither static analysis

Slither is Python-based, separate from the Node.js toolchain:
```bash
pip install slither-analyzer --break-system-packages
slither .
```
Review any findings — document and either fix or justify each one in your design doc, as required by the brief.

## 6. Deploy to Sepolia testnet

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Fill in `.env` with:
   - `SEPOLIA_RPC_URL` — get a free endpoint from [Alchemy](https://www.alchemy.com/) or [Infura](https://www.infura.io/) (sign up, create an app, select Sepolia).
   - `PRIVATE_KEY` — your test wallet's private key (use a **throwaway/test wallet only**, never your real one). Export it from MetaMask: Account details → Show private key.
   - `ETHERSCAN_API_KEY` — free from [etherscan.io/apis](https://etherscan.io/apis), used to verify the contract's source code publicly.
3. Fund your wallet with Sepolia test ETH from a faucet (e.g. https://sepoliafaucet.com/).
4. Deploy:
   ```bash
   npx hardhat run scripts/deploy.js --network sepolia
   ```
   This deploys the contract and also creates an initial demo batch, so it's ready to interact with immediately. Copy the printed contract address.
5. Verify on Etherscan (command is printed at the end of the deploy script, or run manually):
   ```bash
   npx hardhat verify --network sepolia <DEPLOYED_ADDRESS> "https://yourapp.example/metadata/{id}.json"
   ```

## Troubleshooting

| Problem | Likely fix |
|---|---|
| `Hardhat only supports ESM projects` | You got Hardhat 3 — reinstall Hardhat 2 as shown in step 1. |
| Compile error mentioning `mcopy` opcode | Make sure `hardhat.config.js` has `evmVersion: "cancun"` under `solidity.settings` — it's already set in this file, but check if you changed the Solidity version. |
| `npx hardhat verify` fails with "already verified" | That's fine — it means it worked on a previous attempt. |
| Deploy script fails with insufficient funds | Get more test ETH from a Sepolia faucet; deployment + batch creation costs a small amount of gas. |
| `.env` values not being read | Make sure the file is named exactly `.env` (not `.env.txt`) and is in the project root, next to `hardhat.config.js`. |

## What's in this folder

```
contracts/GoldBatchToken.sol   — the ERC-1155 batch token with KYC whitelist gate
test/GoldBatchToken.test.js    — full test suite (17 tests)
scripts/deploy.js              — deployment script (Sepolia-ready)
hardhat.config.js              — Hardhat + Solidity + network config
.env.example                   — copy to .env and fill in your own values (never commit .env)
```
