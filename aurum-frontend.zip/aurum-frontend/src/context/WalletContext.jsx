import { createContext, useContext, useState, useCallback, useEffect } from "react";
import { connectMetaMask, onAccountsChanged, isMetaMaskAvailable } from "../lib/contract";

const WalletContext = createContext(null);

export function WalletProvider({ children }) {
  const [address, setAddress] = useState(null);
  const [chainId, setChainId] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState(null);

  const connect = useCallback(async () => {
    setConnecting(true);
    setError(null);
    try {
      const { address, chainId } = await connectMetaMask();
      setAddress(address);
      setChainId(chainId);
      return address;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setConnecting(false);
    }
  }, []);

  function disconnect() {
    setAddress(null);
    setChainId(null);
  }

  useEffect(() => {
    if (!isMetaMaskAvailable()) return;
    return onAccountsChanged((accounts) => {
      if (!accounts || accounts.length === 0) {
        disconnect();
      } else {
        setAddress(accounts[0]);
      }
    });
  }, []);

  return (
    <WalletContext.Provider
      value={{ address, chainId, connecting, error, isConnected: Boolean(address), connect, disconnect }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within a WalletProvider");
  return ctx;
}
