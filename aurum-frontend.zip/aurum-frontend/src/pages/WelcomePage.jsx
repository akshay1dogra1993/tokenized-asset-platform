import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useWallet } from "../context/WalletContext";
import { useTheme } from "../context/ThemeContext";
import { isMetaMaskAvailable } from "../lib/contract";

export default function WelcomePage() {
  const { connect, connecting, error } = useWallet();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [localError, setLocalError] = useState(null);

  async function handleConnect() {
    setLocalError(null);
    try {
      await connect();
      navigate("/auth");
    } catch (err) {
      setLocalError(err.message);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background:
          "radial-gradient(60% 50% at 50% 0%, color-mix(in srgb, var(--gold) 10%, transparent), transparent), var(--bg)",
        display: "flex",
        flexDirection: "column",
        fontFamily: "var(--font-body)",
        color: "var(--text)",
      }}
    >
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "28px 32px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <div
            style={{
              width: 26,
              height: 26,
              borderRadius: 7,
              background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))",
            }}
            aria-hidden="true"
          />
          <span style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 560 }}>Aurum</span>
        </div>
        <button
          onClick={toggleTheme}
          aria-label="Toggle light or dark mode"
          style={{
            width: 36,
            height: 36,
            borderRadius: 9,
            background: "var(--panel-2)",
            border: "1px solid var(--line)",
            color: "var(--text)",
            cursor: "pointer",
            fontSize: 15,
          }}
        >
          {theme === "dark" ? "☀" : "☾"}
        </button>
      </header>

      <main
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          padding: "0 24px",
        }}
      >
        <p
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 12,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            color: "var(--text-faint)",
            margin: "0 0 20px",
          }}
        >
          Sepolia testnet demo
        </p>

        <h1
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: 450,
            fontSize: "clamp(2.4rem, 6vw, 4.2rem)",
            lineHeight: 1.05,
            letterSpacing: "-0.01em",
            margin: 0,
            maxWidth: 720,
          }}
        >
          Own gold,
          <br />
          <em style={{ fontStyle: "italic", color: "var(--gold-bright)" }}>by the gram.</em>
        </h1>

        <div
          aria-hidden="true"
          style={{
            width: 84,
            height: 2,
            margin: "26px 0",
            background: "linear-gradient(90deg, transparent, var(--gold-bright), transparent)",
            backgroundSize: "200% 100%",
            animation: "shimmer 3.5s ease-in-out infinite",
          }}
        />

        <p
          style={{
            fontSize: 16,
            lineHeight: 1.6,
            color: "var(--text-dim)",
            maxWidth: 460,
            margin: "0 0 40px",
          }}
        >
          Fractional ownership of vaulted gold, tokenized on-chain. Every holder is KYC-verified —
          every gram is traceable to a real custody record.
        </p>

        <button
          onClick={handleConnect}
          disabled={connecting}
          style={{
            height: 48,
            padding: "0 28px",
            fontSize: 15,
            fontWeight: 600,
            color: "var(--gold-on)",
            background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))",
            border: "none",
            borderRadius: 10,
            cursor: connecting ? "default" : "pointer",
            opacity: connecting ? 0.7 : 1,
          }}
        >
          {connecting ? "Connecting…" : "Connect wallet"}
        </button>

        {!isMetaMaskAvailable() && (
          <p style={{ marginTop: 16, fontSize: 13, color: "var(--text-faint)" }}>
            MetaMask not detected.{" "}
            <a
              href="https://metamask.io/download/"
              target="_blank"
              rel="noreferrer"
              style={{ color: "var(--gold)", textDecoration: "underline" }}
            >
              Install it
            </a>{" "}
            to continue.
          </p>
        )}

        {(localError || error) && isMetaMaskAvailable() && (
          <p style={{ marginTop: 16, fontSize: 13, color: "var(--bad)" }}>{localError || error}</p>
        )}
      </main>

      <footer style={{ textAlign: "center", padding: "20px", fontSize: 12, color: "var(--text-faint)" }}>
        Vault: Zurich Secure Storage · Contract not yet deployed to mainnet — demo purposes only
      </footer>

      <style>{`
        @keyframes shimmer {
          0%, 100% { background-position: 200% 0; }
          50% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
}
