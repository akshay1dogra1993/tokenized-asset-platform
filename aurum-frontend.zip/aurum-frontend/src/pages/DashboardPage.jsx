import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useWallet } from "../context/WalletContext";
import { useTheme } from "../context/ThemeContext";
import * as api from "../lib/api";

export default function DashboardPage() {
  const { user, token, logout } = useAuth();
  const { address, disconnect } = useWallet();
  const { theme, toggleTheme } = useTheme();
  const [view, setView] = useState("overview");

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)", fontFamily: "var(--font-body)" }}>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "26px 24px" }}>
        <TopBar
          address={address}
          user={user}
          theme={theme}
          onToggleTheme={toggleTheme}
          onLogout={() => {
            logout();
            disconnect();
          }}
        />
        <Tabs view={view} setView={setView} />
        {view === "overview" && <Overview />}
        {view === "portfolio" && <Portfolio token={token} />}
        {view === "admin" && <Admin token={token} user={user} />}
      </div>
    </div>
  );
}

function TopBar({ address, user, theme, onToggleTheme, onLogout }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingBottom: 18, borderBottom: "1px solid var(--line)", marginBottom: 20 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))" }} aria-hidden="true" />
        <span style={{ fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 560 }}>Aurum</span>
        <span style={{ fontSize: 11, color: "var(--text-faint)", padding: "2px 7px", border: "1px solid var(--line)", borderRadius: 20 }}>
          {user?.role || "Investor"}
        </span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 12, color: "var(--text-faint)", fontFamily: "var(--font-mono)" }}>
          {user?.fullName}
          {address ? ` · ${address.slice(0, 6)}…${address.slice(-4)}` : ""}
        </span>
        <button onClick={onToggleTheme} aria-label="Toggle theme" style={iconButtonStyle}>
          {theme === "dark" ? "☀" : "☾"}
        </button>
        <button onClick={onLogout} style={{ ...iconButtonStyle, width: "auto", padding: "0 12px", fontSize: 12 }}>
          Log out
        </button>
      </div>
    </div>
  );
}

function Tabs({ view, setView }) {
  const tabs = [
    { key: "overview", label: "Overview" },
    { key: "portfolio", label: "Portfolio" },
    { key: "admin", label: "Admin" },
  ];
  return (
    <div style={{ display: "flex", gap: 26, marginBottom: 24, borderBottom: "1px solid var(--line)" }}>
      {tabs.map((t) => (
        <button
          key={t.key}
          onClick={() => setView(t.key)}
          style={{
            background: "none",
            border: "none",
            fontSize: 13,
            fontWeight: 500,
            padding: "0 0 12px",
            marginBottom: -1,
            cursor: "pointer",
            color: view === t.key ? "var(--text)" : "var(--text-dim)",
            borderBottom: view === t.key ? "2px solid var(--gold)" : "2px solid transparent",
          }}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

function Overview() {
  const [assets, setAssets] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getAssets()
      .then(setAssets)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const totalTokens = assets.reduce((sum, a) => sum + (a.totalTokens || 0), 0);

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
        <div style={panelStyle}>
          <p style={eyebrowStyle}>Listed assets</p>
          <p style={{ fontSize: 22, fontWeight: 500, margin: 0 }}>{assets.length}</p>
        </div>
        <div style={panelStyle}>
          <p style={eyebrowStyle}>Total tokens across assets</p>
          <p style={{ fontSize: 22, fontWeight: 500, margin: 0 }}>{totalTokens.toLocaleString()}</p>
        </div>
      </div>

      <p style={{ fontSize: 12, fontWeight: 600, color: "var(--text-dim)", textTransform: "uppercase", letterSpacing: "0.05em", margin: "0 0 10px" }}>
        Assets
      </p>

      {loading && <p style={{ fontSize: 13, color: "var(--text-faint)" }}>Loading…</p>}
      {error && <p style={{ fontSize: 13, color: "var(--bad)" }}>{error} — is the backend running on the expected port?</p>}
      {!loading && !error && assets.length === 0 && (
        <p style={{ fontSize: 13, color: "var(--text-faint)" }}>No assets listed yet. Create one from the Admin tab.</p>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {assets.map((a) => (
          <div key={a._id} style={{ ...panelStyle, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 16px" }}>
            <div>
              <p style={{ fontSize: 13, fontWeight: 500, margin: 0 }}>{a.name}</p>
              <p style={{ fontSize: 12, color: "var(--text-faint)", margin: "3px 0 0" }}>{a.description || a.assetType}</p>
            </div>
            <span style={{ fontSize: 12, color: "var(--gold)", fontWeight: 600 }}>
              {a.availableTokens} / {a.totalTokens} tokens
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Portfolio({ token }) {
  const [assets, setAssets] = useState([]);
  const [ownership, setOwnership] = useState([]);
  const [selectedAsset, setSelectedAsset] = useState("");
  const [tokens, setTokens] = useState("");
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState(null);
  const [loadingOwnership, setLoadingOwnership] = useState(true);

  useEffect(() => {
    api.getAssets().then((list) => {
      setAssets(list);
      if (list.length > 0) setSelectedAsset(list[0]._id);
    });
    refreshOwnership();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function refreshOwnership() {
    setLoadingOwnership(true);
    api
      .getMyOwnership(token)
      .then(setOwnership)
      .catch(() => setOwnership([]))
      .finally(() => setLoadingOwnership(false));
  }

  async function handleBuy(e) {
    e.preventDefault();
    setStatus(null);
    if (!selectedAsset || !tokens || !amount) {
      setStatus({ type: "error", text: "Choose an asset and enter tokens and amount." });
      return;
    }
    try {
      await api.buyInvestment(token, { asset: selectedAsset, tokens: Number(tokens), amount: Number(amount) });
      setStatus({ type: "success", text: `Bought ${tokens} tokens.` });
      setTokens("");
      setAmount("");
      refreshOwnership();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    }
  }

  async function handleSell(e) {
    e.preventDefault();
    setStatus(null);
    if (!selectedAsset || !tokens || !amount) {
      setStatus({ type: "error", text: "Choose an asset and enter tokens and amount." });
      return;
    }
    try {
      const res = await api.sellInvestment(token, { asset: selectedAsset, tokens: Number(tokens), amount: Number(amount) });
      setStatus({ type: "success", text: `Sold ${res.soldTokens} tokens. Remaining: ${res.remainingTokens}.` });
      setTokens("");
      setAmount("");
      refreshOwnership();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    }
  }

  return (
    <div>
      <div style={panelStyle}>
        <p style={eyebrowStyle}>My holdings</p>
        {loadingOwnership && <p style={{ fontSize: 13, color: "var(--text-faint)" }}>Loading…</p>}
        {!loadingOwnership && ownership.length === 0 && (
          <p style={{ fontSize: 13, color: "var(--text-faint)" }}>No ownership records yet — buy some tokens below.</p>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {ownership.map((o) => (
            <div key={o._id} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--line)" }}>
              <span style={{ fontSize: 13 }}>{o.asset?.name || o.asset}</span>
              <span style={{ fontSize: 13, color: "var(--gold)", fontFamily: "var(--font-mono)" }}>
                {o.tokenQuantity} tokens · {o.ownershipPercentage?.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ ...panelStyle, marginTop: 14 }}>
        <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 16px" }}>Buy / sell tokens</p>
        <label style={labelStyle}>Asset</label>
        <select value={selectedAsset} onChange={(e) => setSelectedAsset(e.target.value)} style={{ ...inputStyle, marginBottom: 12 }}>
          {assets.map((a) => (
            <option key={a._id} value={a._id}>
              {a.name}
            </option>
          ))}
        </select>
        <label style={labelStyle}>Tokens</label>
        <input value={tokens} onChange={(e) => setTokens(e.target.value)} type="number" placeholder="10" style={{ ...inputStyle, marginBottom: 12 }} />
        <label style={labelStyle}>Amount (USD)</label>
        <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" placeholder="500" style={{ ...inputStyle, marginBottom: 14 }} />
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={handleBuy} style={{ ...primaryButtonStyle, flex: 1 }}>
            Buy
          </button>
          <button onClick={handleSell} style={{ ...secondaryButtonStyle, flex: 1 }}>
            Sell
          </button>
        </div>
        {status && <p style={{ fontSize: 13, marginTop: 12, color: status.type === "error" ? "var(--bad)" : "var(--good)" }}>{status.text}</p>}
      </div>
    </div>
  );
}

function Admin({ token, user }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [totalValue, setTotalValue] = useState("");
  const [totalTokens, setTotalTokens] = useState("");
  const [status, setStatus] = useState(null);

  async function handleCreate(e) {
    e.preventDefault();
    setStatus(null);
    try {
      await api.createAsset(token, {
        name,
        description,
        assetType: "Gold",
        totalValue: Number(totalValue),
        totalTokens: Number(totalTokens),
        availableTokens: Number(totalTokens),
      });
      setStatus({ type: "success", text: `Asset "${name}" created.` });
      setName("");
      setDescription("");
      setTotalValue("");
      setTotalTokens("");
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    }
  }

  return (
    <div>
      {user?.role !== "AssetOwner" && user?.role !== "Admin" && (
        <div style={bannerStyle}>
          Your account role is <strong>{user?.role}</strong>. The backend's <code>/api/assets/create</code> route
          doesn't currently restrict by role, but it probably should — worth adding{" "}
          <code>roleMiddleware("AssetOwner", "Admin")</code> there.
        </div>
      )}
      <form onSubmit={handleCreate} style={panelStyle}>
        <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 16px" }}>Create an asset listing</p>
        <label style={labelStyle}>Name</label>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Gold Batch #0 — Sept 2026" style={{ ...inputStyle, marginBottom: 12 }} />
        <label style={labelStyle}>Description</label>
        <input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Vault: Zurich Secure Storage" style={{ ...inputStyle, marginBottom: 12 }} />
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Total value (USD)</label>
            <input value={totalValue} onChange={(e) => setTotalValue(e.target.value)} type="number" placeholder="50000" style={inputStyle} />
          </div>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Total tokens</label>
            <input value={totalTokens} onChange={(e) => setTotalTokens(e.target.value)} type="number" placeholder="1000" style={inputStyle} />
          </div>
        </div>
        <button type="submit" style={{ ...primaryButtonStyle, width: "100%" }}>
          Create asset
        </button>
        {status && <p style={{ fontSize: 13, marginTop: 12, color: status.type === "error" ? "var(--bad)" : "var(--good)" }}>{status.text}</p>}
      </form>
    </div>
  );
}

const panelStyle = { padding: 20, borderRadius: 14, background: "var(--panel)", border: "1px solid var(--line)" };
const eyebrowStyle = { fontSize: 11, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--text-faint)", margin: "0 0 8px" };
const labelStyle = { display: "block", fontSize: 12, color: "var(--text-dim)", marginBottom: 6 };
const inputStyle = { width: "100%", height: 40, padding: "0 12px", fontSize: 13, color: "var(--text)", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: 8, boxSizing: "border-box" };
const primaryButtonStyle = { height: 40, fontSize: 13, fontWeight: 600, color: "var(--gold-on)", background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))", border: "none", borderRadius: 9, cursor: "pointer" };
const secondaryButtonStyle = { height: 40, fontSize: 13, fontWeight: 600, color: "var(--gold)", background: "var(--panel-2)", border: "1px solid var(--gold)", borderRadius: 9, cursor: "pointer" };
const iconButtonStyle = { width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: 9, color: "var(--text)", cursor: "pointer" };
const bannerStyle = { fontSize: 12, color: "var(--text-dim)", background: "var(--panel-2)", border: "1px solid var(--line)", borderRadius: 10, padding: "10px 14px", marginBottom: 18 };
