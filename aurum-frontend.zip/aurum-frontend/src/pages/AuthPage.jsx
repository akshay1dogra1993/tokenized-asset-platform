import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useWallet } from "../context/WalletContext";
import { PASSWORD_RULES, passwordMeetsPolicy } from "../lib/password";

export default function AuthPage() {
  const [mode, setMode] = useState("signup"); // "signup" | "login"
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);
  const [touched, setTouched] = useState(false);

  const { signup, login, linkWallet } = useAuth();
  const { address, isConnected } = useWallet();
  const navigate = useNavigate();

  const policyOk = passwordMeetsPolicy(password);

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched(true);
    setFormError(null);

    if (mode === "signup" && !fullName.trim()) {
      setFormError("Enter your full name.");
      return;
    }
    if (mode === "signup" && !policyOk) {
      setFormError("Password doesn't meet the requirements below yet.");
      return;
    }

    setSubmitting(true);
    try {
      if (mode === "signup") {
        await signup(fullName, email, password);
      } else {
        await login(email, password);
      }
      if (isConnected && address) {
        await linkWallet(address).catch(() => {}); // non-fatal if this fails
      }
      navigate("/dashboard");
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--bg)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "var(--font-body)",
        color: "var(--text)",
        padding: 24,
      }}
    >
      <div style={{ width: "100%", maxWidth: 400 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, marginBottom: 18 }}>
            <div
              style={{
                width: 24,
                height: 24,
                borderRadius: 7,
                background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))",
              }}
              aria-hidden="true"
            />
            <span style={{ fontFamily: "var(--font-display)", fontSize: 16, fontWeight: 560 }}>Aurum</span>
          </div>
          <h1
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 450,
              fontSize: 28,
              margin: "0 0 6px",
            }}
          >
            {mode === "signup" ? "Create your account" : "Welcome back"}
          </h1>
          <p style={{ fontSize: 13, color: "var(--text-dim)", margin: 0 }}>
            {isConnected
              ? `Wallet connected · ${address.slice(0, 6)}…${address.slice(-4)}`
              : "No wallet connected — go back to connect one first."}
          </p>
        </div>

        <div
          style={{
            display: "flex",
            gap: 4,
            background: "var(--panel-2)",
            padding: 4,
            borderRadius: 10,
            marginBottom: 22,
          }}
        >
          {["signup", "login"].map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setMode(m);
                setFormError(null);
              }}
              style={{
                flex: 1,
                padding: "9px 0",
                fontSize: 13,
                fontWeight: 600,
                borderRadius: 7,
                border: "none",
                cursor: "pointer",
                background: mode === m ? "var(--panel)" : "transparent",
                color: mode === m ? "var(--text)" : "var(--text-dim)",
                boxShadow: mode === m ? "0 1px 0 var(--line)" : "none",
              }}
            >
              {m === "signup" ? "Sign up" : "Log in"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} noValidate>
          {mode === "signup" && (
            <>
              <label style={fieldLabelStyle} htmlFor="fullName">
                Full name
              </label>
              <input
                id="fullName"
                type="text"
                required
                autoComplete="name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Jane Investor"
                style={{ ...inputStyle, marginBottom: 14 }}
              />
            </>
          )}

          <label style={fieldLabelStyle} htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            style={inputStyle}
          />

          <label style={{ ...fieldLabelStyle, marginTop: 14 }} htmlFor="password">
            Password
          </label>
          <div style={{ position: "relative" }}>
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              required
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setTouched(true);
              }}
              placeholder="••••••••"
              style={{ ...inputStyle, paddingRight: 64 }}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              style={{
                position: "absolute",
                right: 10,
                top: "50%",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                color: "var(--text-faint)",
                fontSize: 12,
                cursor: "pointer",
              }}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>

          {mode === "signup" && (
            <ul style={{ listStyle: "none", margin: "10px 0 0", padding: 0, display: "grid", gap: 5 }}>
              {PASSWORD_RULES.map((rule) => {
                const pass = rule.test(password);
                return (
                  <li
                    key={rule.key}
                    style={{
                      fontSize: 12,
                      display: "flex",
                      alignItems: "center",
                      gap: 7,
                      color: !touched ? "var(--text-faint)" : pass ? "var(--good)" : "var(--text-faint)",
                    }}
                  >
                    <span
                      aria-hidden="true"
                      style={{
                        width: 14,
                        height: 14,
                        borderRadius: "50%",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 9,
                        border: `1px solid ${pass && touched ? "var(--good)" : "var(--line-strong)"}`,
                        color: pass && touched ? "var(--good)" : "transparent",
                      }}
                    >
                      ✓
                    </span>
                    {rule.label}
                  </li>
                );
              })}
            </ul>
          )}

          {formError && (
            <p role="alert" style={{ color: "var(--bad)", fontSize: 13, margin: "14px 0 0" }}>
              {formError}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            style={{
              width: "100%",
              height: 46,
              marginTop: 20,
              fontSize: 14,
              fontWeight: 600,
              color: "var(--gold-on)",
              background: "linear-gradient(135deg, var(--gold-bright), var(--gold-deep))",
              border: "none",
              borderRadius: 10,
              cursor: submitting ? "default" : "pointer",
              opacity: submitting ? 0.7 : 1,
            }}
          >
            {submitting
              ? "Please wait…"
              : mode === "signup"
              ? "Create account"
              : "Log in"}
          </button>
        </form>
      </div>
    </div>
  );
}

const fieldLabelStyle = {
  display: "block",
  fontSize: 12,
  color: "var(--text-dim)",
  marginBottom: 6,
};

const inputStyle = {
  width: "100%",
  height: 42,
  padding: "0 14px",
  fontSize: 14,
  color: "var(--text)",
  background: "var(--panel-2)",
  border: "1px solid var(--line)",
  borderRadius: 9,
};
