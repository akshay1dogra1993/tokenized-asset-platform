import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useWallet } from "../context/WalletContext";

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();
  const { isConnected } = useWallet();

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--bg)" }}>
        <p style={{ color: "var(--text-dim)", fontFamily: "var(--font-body)" }}>Loading…</p>
      </div>
    );
  }

  if (!isConnected) return <Navigate to="/" replace />;
  if (!isAuthenticated) return <Navigate to="/auth" replace />;

  return children;
}
