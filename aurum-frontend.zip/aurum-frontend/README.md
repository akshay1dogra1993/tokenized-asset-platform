# Aurum — Tokenized Gold Frontend

A production-style React app (Vite) with three pages, built to match your actual uploaded backend (`tokenized-asset-platform-backend`):

1. **Welcome** (`/`) — hero page with a real MetaMask connection (`ethers.js`), theme toggle.
2. **Auth** (`/auth`) — sign up / log in, with a live password-requirement checklist (8+ chars, one uppercase, one number, one special character) enforced both here and on the backend.
3. **Dashboard** (`/dashboard`, route-protected) — Overview (asset listings), Portfolio (holdings + buy/sell), Admin (create an asset listing).

## Run it

```bash
npm install
cp .env.example .env   # edit VITE_API_BASE if your backend isn't on localhost:5000
npm run dev
```

Requires your backend running (see the `CHANGES.md` in the backend package for bug fixes I made so it actually boots and the endpoints below exist).

## How pages map to your backend's real endpoints

| Page | Calls |
|---|---|
| Welcome | Real `ethers.js` `BrowserProvider` → MetaMask `eth_requestAccounts` |
| Auth (sign up) | `POST /api/users/register` `{ fullName, email, password }` |
| Auth (log in) | `POST /api/users/login` `{ email, password }` |
| Dashboard load | `GET /api/users/me` (session restore), `POST /api/users/wallet` (links connected address) |
| Overview | `GET /api/assets` |
| Portfolio | `GET /api/ownership/my`, `POST /api/investments/buy`, `POST /api/investments/sell` |
| Admin | `POST /api/assets/create` |

**Important:** three of these routes (`/api/users/me`, `PATCH /api/users/wallet`, `GET /api/ownership/my` reaching a working controller) did not exist or were broken in your original upload. They're fixed in the backend package delivered alongside this — see its `CHANGES.md` for the full list of what I found and changed, and why.

## Password policy

Enforced in `src/lib/password.js` (used for the live checklist in `AuthPage.jsx`) and mirrored server-side in the backend's `userController.js`:

```
at least 8 characters, one uppercase letter, one number, one special character
```

Client-side validation alone is not security — it's UX. The backend must (and now does) enforce the same rule, since anyone can call your API directly, bypassing the frontend entirely.

## Project structure

```
src/
  context/
    AuthContext.jsx      — signup/login/logout, session restore via GET /api/users/me
    WalletContext.jsx     — MetaMask connect/disconnect, account change listener
    ThemeContext.jsx      — dark/light toggle, persisted locally
  lib/
    api.js                — every backend call, matching your real routes exactly
    contract.js            — ethers.js contract helper (not currently called by the
                              dashboard, since your backend's buy/sell are DB-only right
                              now — kept here for when on-chain calls get wired in)
    password.js            — shared password policy + live rule checklist
  components/
    ProtectedRoute.jsx      — requires both wallet connection and login for /dashboard
  pages/
    WelcomePage.jsx
    AuthPage.jsx
    DashboardPage.jsx       — Overview / Portfolio / Admin tabs
```

## Known gaps (matching what's flagged in the backend's CHANGES.md)

- **No KYC/verification flow yet.** Your `User` model has `isVerified`, but nothing sets it. If you want a KYC-style review flow like a whitelist, that's a real addition, not something this frontend currently exposes.
- **Buy/sell are database records only** — nothing here calls a smart contract. `investmentController.js` doesn't touch the chain, so neither does this frontend, for now. If you want actual on-chain minting/transfer wired into "Buy"/"Sell", say so and I'll build it using `lib/contract.js`.
- **`/api/assets/create` has no role restriction on the backend** — the Admin tab shows a warning banner if the logged-in user's role isn't `AssetOwner` or `Admin`, but the request would currently still succeed regardless. This needs a backend fix (`roleMiddleware`), not a frontend one.
